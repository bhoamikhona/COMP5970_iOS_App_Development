//
//  ViewController.swift
//  Assignment3Abzk0039Su20
//
//  Created by Bhoami Khona on 7/9/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var selectButton: UIButton!
    @IBOutlet weak var replaceButton: UIButton!
    @IBOutlet weak var insertButton: UIButton!
    
    var data = ["Thing One", "Thing Two", "Thing Three"]

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpElements()
    }
    
    func setUpElements() {
        styleTextField(textField)
        selectButton.layer.cornerRadius = 25.0
        replaceButton.layer.cornerRadius = 25.0
        insertButton.layer.cornerRadius = 25.0
    }
    
    func styleTextField(_ textfield:UITextField) {
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0, y: textfield.frame.height - 2, width: textfield.frame.width, height: 2)
        bottomLine.backgroundColor = UIColor.init(red: 20/255, green: 177/255, blue: 171/255, alpha: 1).cgColor
        textfield.borderStyle = .none
        textfield.layer.addSublayer(bottomLine)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return data.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return data[row]
    }

    @IBAction func selectButtonPressed(_ sender: UIButton) {
        let row = picker.selectedRow(inComponent: 0)
        let selected = data[row]
        let title = "You Selected \(selected)!"
        let alert = UIAlertController (title: title, message: "Thank you for choosing", preferredStyle: .alert)
        let action = UIAlertAction (title: "You're Welcome", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func replaceButtonPressed(_ sender: Any) {
        let row = picker.selectedRow(inComponent: 0)
        data[row] = textField.text!
        picker.reloadAllComponents()
    }
    
    @IBAction func insertButtonPressed(_ sender: Any) {
        let insertRow = picker.selectedRow(inComponent: 0) + 1
        data.insert(textField.text!, at: insertRow)
        picker.reloadAllComponents()
        picker.selectRow(insertRow, inComponent: 0, animated: true)
    }
}
