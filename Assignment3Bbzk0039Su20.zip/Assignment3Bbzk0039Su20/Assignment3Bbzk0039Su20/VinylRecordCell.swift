//
//  VinylRecordCell.swift
//  Assignment3Bbzk0039Su20
//
//  Created by Bhoami Khona on 7/26/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class VinylRecordCell: UITableViewCell {

    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var record: UILabel!
    @IBOutlet weak var artist: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setVinylRecord(vinylRecord: VinylRecord) {
        cover.image = vinylRecord.cover
        record.text = vinylRecord.record
        artist.text = vinylRecord.artist
    }

}
