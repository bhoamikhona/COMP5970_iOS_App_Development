//
//  VinylRecord.swift
//  Assignment3Bbzk0039Su20
//
//  Created by Bhoami Khona on 7/26/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import Foundation
import UIKit

class VinylRecord {
    
    var cover: UIImage
    var record: String
    var artist: String
    var yearOfRelease: String
    var recordLabel: String
    var tracks: [String] = []
    var durationAndComposer: [String] = []
    
    init(cover: UIImage, record: String, artist: String, yearOfRelease: String, recordLabel: String, tracks: [String], durationAndComposer: [String]) {
        self.cover = cover
        self.record = record
        self.artist = artist
        self.yearOfRelease = yearOfRelease
        self.recordLabel = recordLabel
        self.tracks = tracks
        self.durationAndComposer = durationAndComposer
    }
}
