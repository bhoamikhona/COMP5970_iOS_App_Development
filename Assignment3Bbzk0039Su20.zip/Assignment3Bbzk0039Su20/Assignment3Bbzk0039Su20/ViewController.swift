//
//  ViewController.swift
//  Assignment3Bbzk0039Su20
//
//  Created by Bhoami Khona on 7/26/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var vinylRecords: [VinylRecord] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        vinylRecords = createArray()
        
        tableView.delegate = self
        tableView.dataSource = self
    }

    
    func createArray() -> [VinylRecord] {
        
        // All tracks written by Jimi Hendrix for this album
        let rec1 = VinylRecord(cover: UIImage(named: "are-you-experienced.jpg")!,
                               record: "Are You Experienced?",
                               artist: "The Jimi Hendrix Experience",
                               yearOfRelease: "1967",
                               recordLabel: "Track Records",
                               tracks: ["1. Foxey Lady",
                                        "2. Manic Depression",
                                        "3. Red House",
                                        "4. Can You See Me",
                                        "5. Love or Confusion",
                                        "6. I Don't Live Today",
                                        "7. May This Be Love",
                                        "8. Fire",
                                        "9. Third Stone From The Sun",
                                        "10. Remember",
                                        "11. Are You Experienced"],
                               durationAndComposer: ["Duration: 3:10;  Composer: Curtis Knight & Jimi Hendrix",
                                                     "Duration: 3:31;  Composer:  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 3:45;  Composer:  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 2:35;  Composer:  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 3:05;  Composer:  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 3:48;  Composer:  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 2:55;  Composer:  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 2:30;  Composer:  Curtis Knight, Jimi Hendrix & The Jimi Hendrix Experience",
                                                     "Duration: 6:30  Curtis Knight & Jimi Hendrix",
                                                     "Duration: 2:43  Jimi Hendrix",
                                                     "Duration: 4:02  Curtis Knight & Jimi Hendrix"])
        
        
        let rec2 = VinylRecord(cover: UIImage(named: "sgt-peppers-lonely-hearts-club-band.jpg")!,
                               record: "Sgt. Pepper’s Lonely Hearts Club Band",
                               artist: "The Beatles",
                               yearOfRelease: "1967",
                               recordLabel: "Parlophone",
                               tracks: ["1. Sgt. Pepper's Lonely Hearts Club Band",
                                        "2. With a Little Help From My Friends",
                                        "3. Lucy in the Sky with Diamonds",
                                        "4. Getting Better",
                                        "5. Fixing a Hole",
                                        "6. She's Leaving Home",
                                        "7. Being for the Benefit of Mr. Kite!",
                                        "8. Within You Without You",
                                        "9. When I'm Sixty-Four",
                                        "10. Lovely Rita",
                                        "11. Good Morning Good Morning",
                                        "12. Sgt. Pepper's Lonely Hearts Club Band Reprise",
                                        "13. A Day in the Life"],
                               durationAndComposer: ["Duration: 2:00;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 2:42;  Composer:  John Lennon & Paul McCartney",
                                                     "Duration: 3:28;  Composer:  John Lennon & Paul McCartney",
                                                     "Duration: 2:48;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 2:36;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 3:25;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 2:37;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 5:05;  Composer:  George Harrison",
                                                     "Duration: 2:37;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 2:42;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 2:42;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 1:18;  Composer:  Paul McCartney & John Lennon",
                                                     "Duration: 5:38;  Composer:  John Lennon & Paul McCartney"])
        
        let rec3 = VinylRecord(cover: UIImage(named: "frampton-comes-alive.jpg")!,
                               record: "Frampton Comes Alive!",
                               artist: "Peter Frampton",
                               yearOfRelease: "1976",
                               recordLabel: "A&M",
                               tracks: ["1. Something's Happening",
                                        "2. Doobie Wah",
                                        "3. Show Me the Way",
                                        "4. It's a Plain Shame",
                                        "5. All I Want To Be (Is By Your Side)",
                                        "6. Wind of Change",
                                        "7. Baby, I Love You Way",
                                        "8. I Wanna Go to the Sun",
                                        "9. Penny For Your Thoughts",
                                        "10. (I'll Give You) Money",
                                        "11. Shine On",
                                        "12. Jumpin' Jack Flash",
                                        "13. Lines on My Face",
                                        "14. Do You Feel Like We Do"],
                               durationAndComposer: ["Duration: 5:54  Peter Frampton",
                                                     "Duration: 5:28  Peter Frampton, John Headley-Down, Rick Wills, Tom Johnston",
                                                     "Duration: 4:42;  Composer:  Peter Frampton",
                                                     "Duration: 4:21;  Composer:  Peter Frampton",
                                                     "Duration: 3:27;  Composer:  Peter Frampton",
                                                     "Duration: 2:47;  Composer:  Peter Frampton",
                                                     "Duration: 4:43;  Composer:  Peter Frampton",
                                                     "Duration: 7:02;  Composer:  Peter Frmapton",
                                                     "Duration: 1:23;  Composer:  Peter Frampton",
                                                     "Duration: 5:39;  Composer:  Peter Frampton",
                                                     "Duration: 3:35;  Composer:  Peter Frampton",
                                                     "Duration: 7:45;  Composer:  Mick Jagger, Keith Richards",
                                                     "Duration: 7:06;  Composer:  Peter Frampton",
                                                     "Duration: 14:15; Composer: Peter Frampton, Mick Gallagher, John Siomos, Rick Wills"])
        
        let rec4 = VinylRecord(cover: UIImage(named: "born-to-run.jpg")!,
                               record: "Born To Run",
                               artist: "Bruce Springsteen",
                               yearOfRelease: "1975",
                               recordLabel: "Columbia Records",
                               tracks: ["1. Thunder Road",
                                        "2. Tenth Avenue Freeze-Out",
                                        "3. Night",
                                        "4. Backstreets",
                                        "5. Born To Run",
                                        "6. She's The One",
                                        "7. Meeting Accross the River",
                                        "8. Jungleland"],
                               durationAndComposer: ["Duration: 4:49;  Composer:  Bruce Springsteen",
                                                     "Duration: 3:11;  Composer:  Bruce Springsteen",
                                                     "Duration: 3:00;  Composer:  Bruce Springsteen",
                                                     "Duration: 6:30;  Composer:  Bruce Springsteen",
                                                     "Duration: 4:31;  Composer:  Bruce Springsteen",
                                                     "Duration: 4:30;  Composer:  Bruce Springsteen",
                                                     "Duration: 3:18;  Composer:  Bruce Springsteen",
                                                     "Duration: 9:34;  Composer:  Bruce Springsteen"])
        
        let rec5 = VinylRecord(cover: UIImage(named: "thriller.jpg")!,
                               record: "Thriller",
                               artist: "Michael Jackson",
                               yearOfRelease: "1982",
                               recordLabel: "Epic Records",
                               tracks: ["1. Wanna Be Startin' Somethin'",
                                        "2. Baby Be Mine",
                                        "3. The Girl is Mine",
                                        "4. Thriller",
                                        "5. Beat It",
                                        "6. Billie Jean",
                                        "7. Human Nature",
                                        "8. P.Y.T (Pretty Young Thing)",
                                        "9. The Lady in My Life"],
                               durationAndComposer: ["Duration: 6:02;  Composer:  Michael Jackson",
                                                     "Duration: 4:20;  Composer:  Rod Temperton",
                                                     "Duration: 3:41;  Composer:  Jackson",
                                                     "Duration: 5:57;  Composer:  Temperton",
                                                     "Duration: 4:18;  Composer:  Jackson",
                                                     "Duration: 4:54;  Composer:  Jackson",
                                                     "Duration: 4:07;  Composer:  Steve Porcaro & John Bettis",
                                                     "Duration: 3:58;  Composer:  James Ingram & Jones",
                                                     "Duration: 4:59;  Composer:  Temperton"])
        
        let rec6 = VinylRecord(cover: UIImage(named: "rumours.jpg")!,
                               record: "Rumours",
                               artist: "Fleetwood Mac",
                               yearOfRelease: "1977",
                               recordLabel: "Warner Records",
                               tracks: ["1. I Don't Want to Know",
                                        "2. Dreams",
                                        "3. Never Going Back Again",
                                        "4. Don't Stop",
                                        "5. Go Your Own Way",
                                        "6. Songbird",
                                        "7. The Chain",
                                        "8. You Make Loving Fun",
                                        "9. Second Hand News",
                                        "10. Oh Daddy",
                                        "11. Gold Dust Woman"],
                               durationAndComposer: ["Duration: 3:15;  Composer:  Nicks",
                                                     "Duration: 4:14;  Composer:  Stevie Nicks",
                                                     "Duration: 2:14;  Composer:  Buckingham",
                                                     "Duration: 3:13;  Composer:  Christine McVie",
                                                     "Duration: 3:43;  Composer:  Buckingham",
                                                     "Duration: 3:20;  Composer:  C. McVie",
                                                     "Duration: 4:30;  Composer:  Buckingham, Mick Fleetwood, McVie, & Nicks",
                                                     "Duration: 3:31;  Composer:  C.McVie",
                                                     "Duration: 2:56;  Composer:  Lindsey Buckingham",
                                                     "Duration: 3:56;  Composer:  C. McVie",
                                                     "Duration: 4:56;  Composer:  Nicks"])
        
        let rec7 = VinylRecord(cover: UIImage(named: "led-zeppelin-iv.jpg")!,
                               record: "Led Zeppelin IV",
                               artist: "Led Zeppelin",
                               yearOfRelease: "1971",
                               recordLabel: "Atlantic Records",
                               tracks: ["1. Black Dog",
                                        "2. Rock and Roll",
                                        "3. The Battle of Evermore",
                                        "4. Stairway to Heaven",
                                        "5. Misty Mountain Hop",
                                        "6. Four Sticks",
                                        "7. Going to California",
                                        "8. When the Levee Breaks"],
                               durationAndComposer: ["Duration: 4:54;  Composer:  Jimmy Page, Robert Plant & John Paul Jones",
                                                     "Duration: 3:40;  Composer:  Page, Plant, Jones, John Bonham",
                                                     "Duration: 5:51;  Composer:  Page & Plant",
                                                     "Duration: 8:02;  Composer:  Page & Plant",
                                                     "Duration: 4:38;  Composer:  Page, Plant & Jones",
                                                     "Duration: 4:44;  Composer:  Page & Plant",
                                                     "Duration: 3:31;  Composer:  Page & Plant",
                                                     "Duration: 7:07;  Composer:  Page, Plant, Jones, Bonham, & Memphis Minnie"])
        
        let rec8 = VinylRecord(cover: UIImage(named: "pet-sounds.jpg")!,
                               record: "Pet Sounds",
                               artist: "The Beach Boys",
                               yearOfRelease: "1966",
                               recordLabel: "Capitol Records",
                               tracks: ["1. Wouldn't It Be Nice",
                                        "2. You Still Believe in Me",
                                        "3. That's Not Me",
                                        "4. Don't Talk (Put Your Head on My Shoulder)",
                                        "5. I'm Waiting for the Day",
                                        "6. Let's Go Away For Awhile",
                                        "7. Sloop John B",
                                        "8. God Only Knows",
                                        "9. I know There's an Answer",
                                        "10. Here Today",
                                        "11. I Just Wasn't Made For These Times",
                                        "12. Pet Sounds",
                                        "13. Caroline No"],
                               durationAndComposer: ["Duration: 2:25;  Composer:  Brian Wilson, Tony Asher & Mike Love",
                                                     "Duration: 2:31;  Composer:  Wilson & Asher",
                                                     "Duration: 2:28;  Composer:  Wilson & Asher",
                                                     "Duration: 2:53;  Composer:  Wilson & Asher",
                                                     "Duration: 3:05;  Composer:  Wilson & Love",
                                                     "Duration: 2:18;  Composer:  Wilson",
                                                     "Duration: 2:58;  Composer:  Wilson",
                                                     "Duration: 2:51;  Composer:  Wilson & Asher",
                                                     "Duration: 3:09;  Composer:  Wilson, Terry Sachen, Love",
                                                     "Duration: 2:54;  Composer:  Wilson & Asher",
                                                     "Duration: 3:12;  Composer:  Wilson & Asher",
                                                     "Duration: 2:22;  Composer:  Wilson",
                                                     "Duration: 2:51;  Composer:  Wilson & Asher"])
        
        let rec9 = VinylRecord(cover: UIImage(named: "destiny.jpg")!,
                               record: "Destiny",
                               artist: "The Jacksons",
                               yearOfRelease: "1978",
                               recordLabel: "Epic Rrecords & Sony Music Entertainment",
                               tracks: ["1. Blame It on the Boogie",
                                        "2. Push Me Away",
                                        "3. Things I Do For You",
                                        "4. Shake Your Body (Down to the Ground)",
                                        "5. Destiny",
                                        "6. Bless His Soul",
                                        "7. All Night Dancin'",
                                        "8. That's What You Get (For Being Polite)"],
                               durationAndComposer: ["Duration: 3:36;  Composer:  Composers: Mick Jackson, David Jackson, Elmar Krohn",
                                                     "Duration: 4:19;  Composer:  The Jacksons",
                                                     "Duration: 4:05;  Composer:  The Jacksons",
                                                     "Duration: 8:00;  Composer:  Michael Jackson & Randy Jackson",
                                                     "Duration: 4:55;  Composer:  The Jacksons",
                                                     "Duration: 4:57;  Composer:  The Jacksons",
                                                     "Duration: 6:11;  Composer:  Michael Jackson & Randy Jackson",
                                                     "Duration: 4:57;  Composer:  Michael Jackson & Randy Jackson"])
        
        let rec10 = VinylRecord(cover: UIImage(named: "business-as-usual.jpg")!,
                                record: "Business As Usual",
                                artist: "Men At Work",
                                yearOfRelease: "1981",
                                recordLabel: "Columbia Records",
                                tracks: ["1. Who Can It Be Now?",
                                         "2. I Can See It in Your Eyes",
                                         "3. Down Under",
                                         "4. Underground",
                                         "5. Helpless Automation",
                                         "6. People Just love To PLay With Words",
                                         "7. Be Good Johnny",
                                         "8. Touching the Untouchables",
                                         "9. Catch a Star",
                                         "10. Down by the Sea"],
                                durationAndComposer: ["Duration: 3:25;  Composer: Colin Hay",
                                                      "Duration: 3:32;  Composer: Hay",
                                                      "Duration: 3:45;  Composer: Hay, Ron Strykert",
                                                      "Duration: 3:07;  Composer: Hay",
                                                      "Duration: 3:23;  Composer: Greg Ham",
                                                      "Duration: 3:33;  Composer: Strykert",
                                                      "Duration: 3:39;  Composer: Hay, Ham",
                                                      "Duration: 3:41;  Composer: Hay, Strykert",
                                                      "Duration: 3:31;  Composer: Hay",
                                                      "Duration: 6:53;  Composer: Hay, Strykert, Ham, Jerry Speiser"])
        
        vinylRecords.append(rec1)
        vinylRecords.append(rec2)
        vinylRecords.append(rec3)
        vinylRecords.append(rec4)
        vinylRecords.append(rec5)
        vinylRecords.append(rec6)
        vinylRecords.append(rec7)
        vinylRecords.append(rec8)
        vinylRecords.append(rec9)
        vinylRecords.append(rec10)
        
        
        return vinylRecords
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "masterToDetail" {
            let destinationViewController = segue.destination as! DetailViewController
            destinationViewController.vinylRecord = sender as? VinylRecord
        }
    }
    
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        
        var recordTextField = UITextField()
        var artistTextField = UITextField()
        
        let alert = UIAlertController(title: "Add New Vinyl Record", message: "", preferredStyle: .alert)
        
        let action = UIAlertAction(title: "Add New Record", style: .default) { (action) in
            self.vinylRecords.append(VinylRecord(cover: UIImage(named: "default.jpg")!, record: recordTextField.text!, artist: artistTextField.text!, yearOfRelease: "", recordLabel: "", tracks: [""], durationAndComposer: [""]))
            
            self.tableView.reloadData()
        }
        
        alert.addTextField { (alertTextField) in
            alertTextField.placeholder = "Vinyl Record"
            recordTextField = alertTextField
        }
        
        alert.addTextField{ (alertTextField) in
            alertTextField.placeholder = "Artist"
            artistTextField = alertTextField
        }
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
        
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vinylRecords.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let rec = vinylRecords[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "vinylRecordCell") as! VinylRecordCell
        cell.setVinylRecord(vinylRecord: rec)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let record = vinylRecords[indexPath.row]
        performSegue(withIdentifier: "masterToDetail", sender: record)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            vinylRecords.remove(at: indexPath.row)
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
        }
    }
    
}
