//
//  DetailViewController.swift
//  Assignment3Bbzk0039Su20
//
//  Created by Bhoami Khona on 7/26/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var recordLabel: UILabel!
    @IBOutlet weak var artistLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var recordLabelLabel: UILabel!
    
    @IBOutlet weak var trackTableView: UITableView!
    
    var vinylRecord: VinylRecord?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    func setUI() {
        cover.image = vinylRecord?.cover
        recordLabel.text = vinylRecord?.record
        artistLabel.text = vinylRecord?.artist
        yearLabel.text = vinylRecord?.yearOfRelease
        recordLabelLabel.text = vinylRecord?.recordLabel
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (vinylRecord?.tracks.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "trackCell", for: indexPath)
        
        cell.textLabel?.text = vinylRecord?.tracks[indexPath.row]
        cell.detailTextLabel?.text = vinylRecord?.durationAndComposer[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
