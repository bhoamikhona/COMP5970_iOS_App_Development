//
//  EditViewController.swift
//  Assignment3Bbzk0039Su20
//
//  Created by Bhoami Khona on 7/29/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {

    
    @IBOutlet weak var recordTextField: UITextField!
    @IBOutlet weak var artistTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var recordLabelTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func saveButtonPressed(_ sender: UIButton) {
        let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let destvc = (mainStoryboard.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController)!
        self.navigationController?.pushViewController(destvc, animated: true)
        self.dismiss(animated: true, completion: nil)
        
        updateVinylRecord()
        
    }
    
    func updateVinylRecord() {
        
    }
    
    
    
}
