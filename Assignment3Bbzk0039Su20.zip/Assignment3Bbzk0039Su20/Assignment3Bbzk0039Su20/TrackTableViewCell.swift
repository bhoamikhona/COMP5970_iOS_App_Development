//
//  TrackTableViewCell.swift
//  Assignment3Bbzk0039Su20
//
//  Created by Bhoami Khona on 7/29/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class TrackTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setTrackCell() {
        
    }

}
