//
//  ViewController.swift
//  Assignment1Abzk0039Su20
//
//  Created by Bhoami Khona on 5/26/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

