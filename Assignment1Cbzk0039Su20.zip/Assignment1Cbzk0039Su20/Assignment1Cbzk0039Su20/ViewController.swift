//
//  ViewController.swift
//  Assignment1Cbzk0039Su20
//
//  Created by Bhoami Khona on 6/11/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!
    @IBOutlet weak var slider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        slider.value = 0
        
        image1.image = #imageLiteral(resourceName: "war-eagle")
        image2.image = #imageLiteral(resourceName: "roll-tide")
    
        image1.alpha = 1
        image2.alpha = 0
    }

    @IBAction func sliderMoved(_ sender: UISlider) {
        image2.alpha = CGFloat(sender.value)
        image1.alpha = CGFloat(slider.maximumValue - sender.value)
    }
    
}

