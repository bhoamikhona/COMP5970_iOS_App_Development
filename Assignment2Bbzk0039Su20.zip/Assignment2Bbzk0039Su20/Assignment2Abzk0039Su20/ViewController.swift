//
//  ViewController.swift
//  Assignment2Abzk0039Su20
//
//  Created by Bhoami Khona on 6/19/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var loanAmount: UITextField!
    @IBOutlet weak var timePeriod: UITextField!
    @IBOutlet weak var interestRate: UITextField!
    @IBOutlet weak var total: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        total.textColor = UIColor.systemGreen
    }
    
    
    @IBAction func calculatePressed(_ sender: UIButton) {
        if ((loanAmount.text == "") || (timePeriod.text == "") || (interestRate.text == "")) {
            total.textColor = UIColor.red
            total.text = "Please Fill All Fields"
        }
        else {
            total.textColor = UIColor.systemGreen
            let payable = calculate(Double(loanAmount.text!)!, Double(timePeriod.text!)!, Double(interestRate.text!)!)
            total.text = "$ " + payable
        }
    }
    
    
    // p == principal
    // t == time period
    // r == rate of interest
    func calculate(_ p: Double, _ t: Double, _ r: Double) -> String {
        let rate = r/100
        
        let numerator = p * rate * pow((1 + rate), t)
        let denominator = pow((1 + rate), t) - 1

        let payment = numerator/denominator
        return String(format: "%.2f", payment)
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask(rawValue: (UIInterfaceOrientationMask.portrait.rawValue | UIInterfaceOrientationMask.landscapeLeft.rawValue | UIInterfaceOrientationMask.landscapeRight.rawValue))
    }
}

