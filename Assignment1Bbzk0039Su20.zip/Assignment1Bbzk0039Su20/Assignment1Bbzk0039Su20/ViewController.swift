//
//  ViewController.swift
//  Assignment1Bbzk0039Su20
//
//  Created by Bhoami Khona on 6/2/20.
//  Copyright © 2020 Bhoami Khona. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var warEagleButton: UIButton!
    @IBOutlet weak var secButton: UIButton!
    @IBOutlet weak var rollTideButton: UIButton!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        imageView.image = #imageLiteral(resourceName: "sec")
        self.view.backgroundColor = UIColor.init(named: "sec-blue")
        
        warEagleButton.backgroundColor = UIColor.init(named: "sec-yellow")
        warEagleButton.tintColor = UIColor.init(named: "sec-blue")
        
        secButton.backgroundColor = UIColor.init(named: "sec-yellow")
        secButton.tintColor = UIColor.init(named: "sec-blue")
        
        rollTideButton.backgroundColor = UIColor.init(named: "sec-yellow")
        rollTideButton.tintColor = UIColor.init(named: "sec-blue")
        
    }

    @IBAction func warEaglePressed(_ sender: Any) {
        
        imageView.image = #imageLiteral(resourceName: "war-eagle")
        self.view.backgroundColor = UIColor.init(named: "war-eagle-blue")
        
        warEagleButton.backgroundColor = UIColor.init(named: "war-eagle-orange")
        warEagleButton.tintColor = UIColor.init(named: "war-eagle-blue")
        
        secButton.backgroundColor = UIColor.init(named: "war-eagle-orange")
        secButton.tintColor = UIColor.init(named: "war-eagle-blue")
        
        rollTideButton.backgroundColor = UIColor.init(named: "war-eagle-orange")
        rollTideButton.tintColor = UIColor.init(named: "war-eagle-blue")
        
    }
    
    @IBAction func secPressed(_ sender: Any) {
        
        imageView.image = #imageLiteral(resourceName: "sec")
        self.view.backgroundColor = UIColor.init(named: "sec-blue")
        
        warEagleButton.backgroundColor = UIColor.init(named: "sec-yellow")
        warEagleButton.tintColor = UIColor.init(named: "sec-blue")
        
        secButton.backgroundColor = UIColor.init(named: "sec-yellow")
        secButton.tintColor = UIColor.init(named: "sec-blue")
        
        rollTideButton.backgroundColor = UIColor.init(named: "sec-yellow")
        rollTideButton.tintColor = UIColor.init(named: "sec-blue")
        
    }
    
    @IBAction func rollTidePressed(_ sender: Any) {
        
        imageView.image = #imageLiteral(resourceName: "roll-tide")
        self.view.backgroundColor = UIColor.white
        
        warEagleButton.backgroundColor = UIColor.init(named: "roll-tide-red")
        warEagleButton.tintColor = UIColor.white
        
        secButton.backgroundColor = UIColor.init(named: "roll-tide-red")
        secButton.tintColor = UIColor.white
        
        rollTideButton.backgroundColor = UIColor.init(named: "roll-tide-red")
        rollTideButton.tintColor = UIColor.white
        
    }
    
}

